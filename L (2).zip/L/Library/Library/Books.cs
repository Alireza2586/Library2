﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Reflection;

namespace Library
{
    public partial class Books : Form
    {
        private Book Book;
        private BookRepository bookRepository = new BookRepository();
        public event EventHandler BookAdded;
        DataTable table = new DataTable("table");
        public Books()
        {
            InitializeComponent();
        }
        public Books(BookRepository bookRepository)
        {
            InitializeComponent();
            this.bookRepository = bookRepository;
        }
        private void UpdateDataGridView()
        {
            GridBook.DataSource = table;
            GridBook.DataSource = bookRepository.GetAllBook();
        }
        private void BookAddedd(object sender, EventArgs e)
        {
            UpdateDataGridView();
        }

        private void Books_Load(object sender, EventArgs e)
        {
            table.Columns.Add("BookName", Type.GetType("System.String"));
            table.Columns.Add("Author", Type.GetType("System.String"));
            table.Columns.Add("CodeBook", Type.GetType("System.Int32"));
            GridBook.DataSource = table;
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        int index;
        private void GridBook_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            index = e.RowIndex;
            DataGridViewRow row = GridBook.Rows[index];
            BookName.Text = row.Cells[0].Value.ToString();
            Author.Text = row.Cells[1].Value.ToString();
            CodeBook.Text = row.Cells[2].Value.ToString();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            string bookname = BookName.Text;
            string author = Author.Text;
            string codebook = CodeBook.Text;
            try
            {
                if (!string.IsNullOrWhiteSpace(bookname) && !string.IsNullOrWhiteSpace(author) && !string.IsNullOrWhiteSpace(codebook))
                {
                    for (int item = 0; item < GridBook.Rows.Count; item++)
                    {
                        if (CodeBook.Text == GridBook.Rows[item].Cells[2].Value.ToString())   //شرط برای تکراری نبودن کد های عضویت
                        {
                            MessageBox.Show("The CodeBook is duplicated !");
                            return;
                        }
                    }
                    BookAdded += BookAddedd;
                    Book book1 = new Book(bookname, author, codebook);
                    bookRepository.AddBook(book1);
                    //BookAdded?.Invoke(this, EventArgs.Empty);
                    table.Rows.Add(BookName.Text, Author.Text, CodeBook.Text);
                    BookName.Text = "";
                    Author.Text = "";
                    CodeBook.Text = "";
                }
                else
                {
                    MessageBox.Show("Please fill in all fields.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnExport_Click(object sender, EventArgs e)
        {
            TextWriter writer = new StreamWriter(@"C:\Users\Aftab\Desktop\L\Book.txt");
            try
            {
                for (int i = 0; i < GridBook.Rows.Count; i++)
                {
                    for (int j = 0; j < GridBook.Columns.Count; j++)
                    {
                        if (j == GridBook.Columns.Count - 1)
                        {
                            writer.Write("\t" + GridBook.Rows[i].Cells[j].Value.ToString());
                        }
                        else
                            writer.Write("\t" + GridBook.Rows[i].Cells[j].Value.ToString() + "\t" + "|");
                    }
                    writer.WriteLine("");
                }
                writer.Close();
                MessageBox.Show("Data Exported !");
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        private void btnImport_Click(object sender, EventArgs e)
        {
            string[] lines = File.ReadAllLines(@"C:\Users\Aftab\Desktop\L\Book.txt");
            string[] values;
            try
            {
                for (int i = 0; i < lines.Length; i++)
                {
                    values = lines[i].ToString().Split('|');
                    string[] row = new string[values.Length];
                    for (int j = 0; j < values.Length; j++)
                    {
                        row[j] = values[j].Trim();
                    }
                    table.Rows.Add(row);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            try
            {
                DataGridViewRow newdata = GridBook.Rows[index];
                newdata.Cells[0].Value = BookName.Text;
                newdata.Cells[1].Value = Author.Text;
                newdata.Cells[2].Value = CodeBook.Text;
                BookName.Text = "";
                Author.Text = "";
                CodeBook.Text = "";
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                if (GridBook.SelectedRows.Count >= 0)
                {
                    index = GridBook.CurrentCell.RowIndex;
                    GridBook.Rows.RemoveAt(index);
                    BookName.Text = "";
                    Author.Text = "";
                    CodeBook.Text = "";
                }
            }
            catch(Exception ex) {  MessageBox.Show(ex.Message); }
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            (GridBook.DataSource as DataTable).DefaultView.RowFilter = string.Format("BookName like '%" + btnSearch.Text + "%'");

        }
    }
}
