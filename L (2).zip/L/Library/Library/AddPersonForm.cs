﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using System.IO;

namespace Library
{
    public partial class AddPersonForm : Form
    {
        private PersonRepositori personRepository;
        //public event EventHandler PersonAdded;
        public AddPersonForm(PersonRepositori personRepository)
        {
            InitializeComponent();
            this.personRepository = personRepository;
        }
        public AddPersonForm()
        {
            InitializeComponent();
        }
        private void btnadd_Click(object sender, EventArgs e)
        {
            string firstname = Firstname.Text;
            string lastname = Lastname.Text;
            string code = Code.Text;
            try
            {
                if (!string.IsNullOrWhiteSpace(firstname) && !string.IsNullOrWhiteSpace(lastname) && !string.IsNullOrWhiteSpace(code))
                {
                    Person aperson = new Person(firstname, lastname, code);
                    personRepository.AddPerson(aperson);
                    //PersonAdded?.Invoke(this, EventArgs.Empty);
                    this.Close();
                }
                else
                {
                    MessageBox.Show("Please fill in all fields.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
