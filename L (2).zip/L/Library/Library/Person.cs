﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Library
{
    public class Person
    {
        public string Firstname { get; set; }
        public string Lastname { get; set; }
        public string Code { get; set; }

        public Person (string firstName, string lastName, string code)
        {
            Firstname = firstName;
            Lastname = lastName;
            Code = code;
        }
        public override string ToString()
        {
            return $" \t + {Firstname} + \t + | + \t + {Lastname} + \t + | + \t +{Code}";
        }
    }
}