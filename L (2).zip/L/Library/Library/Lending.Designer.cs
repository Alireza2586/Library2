﻿namespace Library
{
    partial class Lending
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.GridM = new System.Windows.Forms.DataGridView();
            this.GridB = new System.Windows.Forms.DataGridView();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.btnback = new System.Windows.Forms.Button();
            this.btnimportm = new System.Windows.Forms.Button();
            this.btnimportb = new System.Windows.Forms.Button();
            this.CodeM = new System.Windows.Forms.TextBox();
            this.CodeB = new System.Windows.Forms.TextBox();
            this.Time = new System.Windows.Forms.DateTimePicker();
            this.Add = new System.Windows.Forms.Button();
            this.GridL = new System.Windows.Forms.DataGridView();
            this.Export = new System.Windows.Forms.Button();
            this.Import = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.GridM)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.GridB)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.GridL)).BeginInit();
            this.SuspendLayout();
            // 
            // GridM
            // 
            this.GridM.AllowUserToAddRows = false;
            this.GridM.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.GridM.BackgroundColor = System.Drawing.Color.IndianRed;
            this.GridM.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.GridM.Location = new System.Drawing.Point(12, 38);
            this.GridM.Name = "GridM";
            this.GridM.RowHeadersWidth = 51;
            this.GridM.RowTemplate.Height = 24;
            this.GridM.Size = new System.Drawing.Size(367, 495);
            this.GridM.TabIndex = 1;
            this.GridM.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.GridM_CellClick);
            // 
            // GridB
            // 
            this.GridB.AllowUserToAddRows = false;
            this.GridB.BackgroundColor = System.Drawing.SystemColors.ActiveCaption;
            this.GridB.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.GridB.Location = new System.Drawing.Point(385, 38);
            this.GridB.Name = "GridB";
            this.GridB.RowHeadersWidth = 51;
            this.GridB.RowTemplate.Height = 24;
            this.GridB.Size = new System.Drawing.Size(419, 495);
            this.GridB.TabIndex = 2;
            this.GridB.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.GridB_CellClick);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("MV Boli", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(7, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(122, 26);
            this.label1.TabIndex = 3;
            this.label1.Text = "Members :";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("MV Boli", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(380, 9);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(88, 26);
            this.label2.TabIndex = 4;
            this.label2.Text = "Books :";
            // 
            // btnback
            // 
            this.btnback.BackColor = System.Drawing.Color.BlueViolet;
            this.btnback.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnback.Font = new System.Drawing.Font("MV Boli", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnback.Location = new System.Drawing.Point(12, 602);
            this.btnback.Name = "btnback";
            this.btnback.Size = new System.Drawing.Size(78, 36);
            this.btnback.TabIndex = 0;
            this.btnback.Text = "Back";
            this.btnback.UseVisualStyleBackColor = false;
            this.btnback.Click += new System.EventHandler(this.btnback_Click);
            // 
            // btnimportm
            // 
            this.btnimportm.BackColor = System.Drawing.Color.BlueViolet;
            this.btnimportm.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnimportm.Font = new System.Drawing.Font("MV Boli", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnimportm.Location = new System.Drawing.Point(141, 539);
            this.btnimportm.Name = "btnimportm";
            this.btnimportm.Size = new System.Drawing.Size(120, 41);
            this.btnimportm.TabIndex = 5;
            this.btnimportm.Text = "Import M";
            this.btnimportm.UseVisualStyleBackColor = false;
            this.btnimportm.Click += new System.EventHandler(this.btnimportm_Click);
            // 
            // btnimportb
            // 
            this.btnimportb.BackColor = System.Drawing.Color.BlueViolet;
            this.btnimportb.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnimportb.Font = new System.Drawing.Font("MV Boli", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnimportb.Location = new System.Drawing.Point(550, 539);
            this.btnimportb.Name = "btnimportb";
            this.btnimportb.Size = new System.Drawing.Size(120, 41);
            this.btnimportb.TabIndex = 6;
            this.btnimportb.Text = "Import B";
            this.btnimportb.UseVisualStyleBackColor = false;
            this.btnimportb.Click += new System.EventHandler(this.btnimportb_Click);
            // 
            // CodeM
            // 
            this.CodeM.Location = new System.Drawing.Point(1270, 538);
            this.CodeM.Name = "CodeM";
            this.CodeM.Size = new System.Drawing.Size(100, 22);
            this.CodeM.TabIndex = 7;
            // 
            // CodeB
            // 
            this.CodeB.Location = new System.Drawing.Point(1270, 566);
            this.CodeB.Name = "CodeB";
            this.CodeB.Size = new System.Drawing.Size(100, 22);
            this.CodeB.TabIndex = 8;
            // 
            // Time
            // 
            this.Time.CustomFormat = "";
            this.Time.Location = new System.Drawing.Point(1146, 594);
            this.Time.Name = "Time";
            this.Time.Size = new System.Drawing.Size(240, 22);
            this.Time.TabIndex = 9;
            this.Time.Value = new System.DateTime(2024, 6, 4, 0, 0, 0, 0);
            // 
            // Add
            // 
            this.Add.BackColor = System.Drawing.Color.BlueViolet;
            this.Add.Font = new System.Drawing.Font("MV Boli", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Add.Location = new System.Drawing.Point(1022, 539);
            this.Add.Name = "Add";
            this.Add.Size = new System.Drawing.Size(94, 41);
            this.Add.TabIndex = 10;
            this.Add.Text = "Add";
            this.Add.UseVisualStyleBackColor = false;
            this.Add.Click += new System.EventHandler(this.Add_Click);
            // 
            // GridL
            // 
            this.GridL.AllowUserToAddRows = false;
            this.GridL.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.GridL.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.GridL.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.GridL.Location = new System.Drawing.Point(810, 38);
            this.GridL.Name = "GridL";
            this.GridL.RowHeadersWidth = 51;
            this.GridL.RowTemplate.Height = 24;
            this.GridL.Size = new System.Drawing.Size(576, 495);
            this.GridL.TabIndex = 11;
            // 
            // Export
            // 
            this.Export.BackColor = System.Drawing.Color.BlueViolet;
            this.Export.Font = new System.Drawing.Font("MV Boli", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Export.Location = new System.Drawing.Point(922, 539);
            this.Export.Name = "Export";
            this.Export.Size = new System.Drawing.Size(94, 41);
            this.Export.TabIndex = 12;
            this.Export.Text = "Export";
            this.Export.UseVisualStyleBackColor = false;
            this.Export.Click += new System.EventHandler(this.Export_Click);
            // 
            // Import
            // 
            this.Import.BackColor = System.Drawing.Color.BlueViolet;
            this.Import.Font = new System.Drawing.Font("MV Boli", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Import.Location = new System.Drawing.Point(822, 538);
            this.Import.Name = "Import";
            this.Import.Size = new System.Drawing.Size(94, 41);
            this.Import.TabIndex = 13;
            this.Import.Text = "Import";
            this.Import.UseVisualStyleBackColor = false;
            this.Import.Click += new System.EventHandler(this.Import_Click);
            // 
            // Lending
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Purple;
            this.ClientSize = new System.Drawing.Size(1394, 650);
            this.Controls.Add(this.Import);
            this.Controls.Add(this.Export);
            this.Controls.Add(this.GridL);
            this.Controls.Add(this.Add);
            this.Controls.Add(this.Time);
            this.Controls.Add(this.CodeB);
            this.Controls.Add(this.CodeM);
            this.Controls.Add(this.btnimportb);
            this.Controls.Add(this.btnimportm);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.GridB);
            this.Controls.Add(this.GridM);
            this.Controls.Add(this.btnback);
            this.Name = "Lending";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Lending";
            this.Load += new System.EventHandler(this.Lending_Load);
            ((System.ComponentModel.ISupportInitialize)(this.GridM)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.GridB)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.GridL)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.DataGridView GridM;
        private System.Windows.Forms.DataGridView GridB;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnback;
        private System.Windows.Forms.Button btnimportm;
        private System.Windows.Forms.Button btnimportb;
        private System.Windows.Forms.TextBox CodeM;
        private System.Windows.Forms.TextBox CodeB;
        private System.Windows.Forms.DateTimePicker Time;
        private System.Windows.Forms.Button Add;
        private System.Windows.Forms.DataGridView GridL;
        private System.Windows.Forms.Button Export;
        private System.Windows.Forms.Button Import;
    }
}