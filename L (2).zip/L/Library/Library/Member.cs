﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using System.Reflection;

namespace Library
{
    public partial class Member : Form
    {
        private Person person;
        private PersonRepositori personRepository = new PersonRepositori();
        public event EventHandler PersonAdded;
        DataTable table = new DataTable("table");
        public Member()
        {
            InitializeComponent();
        }
        public Member(PersonRepositori personRepository)
        {
            InitializeComponent();
            this.personRepository = personRepository;
        }
        private void UpdateDataGridVeiw()
        {
            GridMember.DataSource = table;
            GridMember.DataSource = personRepository.GetAllPeople();
        }
        private void PersonAddedd(object sender, EventArgs e)
        {
            UpdateDataGridVeiw();
        }

        private void Back_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Add_Click(object sender, EventArgs e)
        {
            string firstname = Firstname.Text;
            string lastname = Lastname.Text;
            string code = Code.Text;
            try
            {
                if (!string.IsNullOrWhiteSpace(firstname) && !string.IsNullOrWhiteSpace(lastname) && !string.IsNullOrWhiteSpace(code))
                {
                    for (int item = 0; item < GridMember.Rows.Count; item++)
                    {
                        if (Code.Text == GridMember.Rows[item].Cells[2].Value.ToString())   //شرط برای تکراری نبودن کد های عضویت
                        {
                            MessageBox.Show("The Code is duplicated !");
                            return;
                        }
                    }
                    PersonAdded += PersonAddedd;
                    Person person1 = new Person(firstname, lastname, code);
                    personRepository.AddPerson(person1);
                    //PersonAdded?.Invoke(this, EventArgs.Empty);
                    table.Rows.Add(Firstname.Text, Lastname.Text, Code.Text);
                    Firstname.Text = "";
                    Lastname.Text = "";
                    Code.Text = "";
                }
                else
                {
                    MessageBox.Show("Please fill in all fields.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void Delete_Click(object sender, EventArgs e)
        {
            if (GridMember.SelectedRows.Count >= 0)
            {
                //var selectedRow = GridMember.SelectedRows[0];
                //var firstname = selectedRow.Cells["Firstname"].Value.ToString();
                //var lastname = selectedRow.Cells["Lastname"].Value.ToString();
                //var code = selectedRow.Cells["Code"].Value.ToString();
                //personRepository.RemovePerson(firstname, lastname, code);
                //UpdateDataGridVeiw();
                index = GridMember.CurrentCell.RowIndex;
                GridMember.Rows.RemoveAt(index);
                Firstname.Text = "";
                Lastname.Text = "";
                Code.Text = "";
            }
        }

        private void Export_Click(object sender, EventArgs e)
        {
            TextWriter writer = new StreamWriter(@"C:\Users\Aftab\Desktop\L\Member.txt");
            for (int i = 0; i < GridMember.Rows.Count; i++)
            {
                for (int j = 0; j < GridMember.Columns.Count; j++)
                {
                    if (j == GridMember.Columns.Count - 1)
                    {
                        writer.Write("\t" + GridMember.Rows[i].Cells[j].Value.ToString());
                    }
                    else
                        writer.Write("\t" + GridMember.Rows[i].Cells[j].Value.ToString() + "\t" + "|");
                }
                writer.WriteLine("");
            }
            writer.Close();
            MessageBox.Show("Data Exported !");
        }

        private void Import_Click(object sender, EventArgs e)
        {
            string[] lines = File.ReadAllLines(@"C:\Users\Aftab\Desktop\L\Member.txt");
            string[] values;
            try
            {
                for (int i = 0; i < lines.Length; i++)
                {
                    values = lines[i].ToString().Split('|');
                    string[] row = new string[values.Length];
                    for (int j = 0; j < values.Length; j++)
                    {
                        row[j] = values[j].Trim();
                    }
                    table.Rows.Add(row);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Member_Load(object sender, EventArgs e)
        {
            table.Columns.Add("Firstname", Type.GetType("System.String"));
            table.Columns.Add("Lastname", Type.GetType("System.String"));
            table.Columns.Add("Code", Type.GetType("System.Int32"));
            GridMember.DataSource = table;
        }

        private void Edit_Click(object sender, EventArgs e)
        {
            try
            {
                DataGridViewRow newdata = GridMember.Rows[index];
                newdata.Cells[0].Value = Firstname.Text;
                newdata.Cells[1].Value = Lastname.Text;
                newdata.Cells[2].Value = Code.Text;
                Firstname.Text = "";
                Lastname.Text = "";
                Code.Text = "";
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            (GridMember.DataSource as DataTable).DefaultView.RowFilter = string.Format("Lastname like '%" + btnSearch.Text + "%'");
        }
        int index;

        private void GridMember_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            index = e.RowIndex;
            DataGridViewRow row = GridMember.Rows[index];
            Firstname.Text = row.Cells[0].Value.ToString();
            Lastname.Text = row.Cells[1].Value.ToString();
            Code.Text = row.Cells[2].Value.ToString();
        }
    }
}
