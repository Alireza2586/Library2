﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Reflection;

namespace Library
{
    public partial class Lending : Form
    {
        DataTable table1 = new DataTable("table1");
        DataTable table2 = new DataTable("table2");
        DataTable table3 = new DataTable("table3");
        public Lending()
        {
            InitializeComponent();
        }

        private void btnback_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnimportm_Click(object sender, EventArgs e)
        {
            string[] lines = File.ReadAllLines(@"C:\Users\Aftab\Desktop\L\Member.txt");
            string[] values;
            try
            {
                for (int i = 0; i < lines.Length; i++)
                {
                    values = lines[i].ToString().Split('|');
                    string[] row = new string[values.Length];
                    for (int j = 0; j < values.Length; j++)
                    {
                        row[j] = values[j].Trim();
                    }
                    table1.Rows.Add(row);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Lending_Load(object sender, EventArgs e)
        {
            table1.Columns.Add("Firstname", Type.GetType("System.String"));
            table1.Columns.Add("Lastname", Type.GetType("System.String"));
            table1.Columns.Add("Code", Type.GetType("System.Int32"));
            GridM.DataSource = table1;
            table2.Columns.Add("BookName", Type.GetType("System.String"));
            table2.Columns.Add("Author", Type.GetType("System.String"));
            table2.Columns.Add("CodeBook", Type.GetType("System.Int32"));
            GridB.DataSource = table2;
            table3.Columns.Add("CodeM", Type.GetType("System.String"));
            table3.Columns.Add("CodeB", Type.GetType("System.String"));
            table3.Columns.Add("Time", Type.GetType("System.String"));
            GridL.DataSource = table3;
        }
        int index;
        private void GridM_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            index = e.RowIndex;
            DataGridViewRow row = GridM.Rows[index];
            CodeM.Text = row.Cells[2].Value.ToString();
        }

        private void GridB_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            index = e.RowIndex;
            DataGridViewRow row = GridB.Rows[index];
            CodeB.Text = row.Cells[2].Value.ToString();
        }

        private void btnimportb_Click(object sender, EventArgs e)
        {
            string[] lines = File.ReadAllLines(@"C:\Users\Aftab\Desktop\L\Book.txt");
            string[] values;
            try
            {
                for (int i = 0; i < lines.Length; i++)
                {
                    values = lines[i].ToString().Split('|');
                    string[] row = new string[values.Length];
                    for (int j = 0; j < values.Length; j++)
                    {
                        row[j] = values[j].Trim();
                    }
                    table2.Rows.Add(row);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Add_Click(object sender, EventArgs e)
        {
            string codem = CodeM.Text;
            string codeb = CodeB.Text;
            string date = Time.Text;
            try
            {
                if (!string.IsNullOrWhiteSpace(codem) && !string.IsNullOrWhiteSpace(codeb) && !string.IsNullOrWhiteSpace(date))
                {

                    table3.Rows.Add(CodeM.Text, CodeB.Text, Time.Text);
                    CodeM.Text = "";
                    CodeB.Text = "";
                    Time.Text = "";
                }
                else
                {
                    MessageBox.Show("Please fill in all fields.");
                }

            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        private void Export_Click(object sender, EventArgs e)
        {
            TextWriter writer = new StreamWriter(@"C:\Users\Aftab\Desktop\L\Lending.txt");
            for (int i = 0; i < GridL.Rows.Count; i++)
            {
                for (int j = 0; j < GridL.Columns.Count; j++)
                {
                    if (j == GridL.Columns.Count - 1)
                    {
                        writer.Write("\t" + GridL.Rows[i].Cells[j].Value.ToString());
                    }
                    else
                        writer.Write("\t" + GridL.Rows[i].Cells[j].Value.ToString() + "\t" + "|");
                }
                writer.WriteLine("");
            }
            writer.Close();
            MessageBox.Show("Data Exported !");
        }

        private void Import_Click(object sender, EventArgs e)
        {
            string[] lines = File.ReadAllLines(@"C:\Users\Aftab\Desktop\L\lending.txt");
            string[] values;
            try
            {
                for (int i = 0; i < lines.Length; i++)
                {
                    values = lines[i].ToString().Split('|');
                    string[] row = new string[values.Length];
                    for (int j = 0; j < values.Length; j++)
                    {
                        row[j] = values[j].Trim();
                    }
                    table3.Rows.Add(row);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
