﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Library
{
    public class BookRepository
    {
        private List<Book> bookss = new List<Book>();
        public void AddBook(Book book) { bookss.Add(book); }
        public bool RemoveBook(string bookname, string author, string codebook)
        {
            var book = bookss.FirstOrDefault(p => p.BookName == bookname && p.Author == author && p.CodeBook == codebook);
            if (book != null)
            {
                bookss.Remove(book);
                return true;
            }
            return false;
        }
        public List<Book> GetAllBook()
        {
            return bookss;
        }
    }
}
