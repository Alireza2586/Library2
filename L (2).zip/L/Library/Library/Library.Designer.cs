﻿namespace Library
{
    partial class Library
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Library));
            this.Members = new System.Windows.Forms.Button();
            this.Books = new System.Windows.Forms.Button();
            this.Lending = new System.Windows.Forms.Button();
            this.Exit = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // Members
            // 
            this.Members.BackColor = System.Drawing.Color.LimeGreen;
            this.Members.Font = new System.Drawing.Font("MV Boli", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Members.Location = new System.Drawing.Point(39, 63);
            this.Members.Name = "Members";
            this.Members.Size = new System.Drawing.Size(143, 74);
            this.Members.TabIndex = 0;
            this.Members.Text = "Members";
            this.Members.UseVisualStyleBackColor = false;
            this.Members.Click += new System.EventHandler(this.Members_Click);
            // 
            // Books
            // 
            this.Books.BackColor = System.Drawing.Color.LimeGreen;
            this.Books.Font = new System.Drawing.Font("MV Boli", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Books.Location = new System.Drawing.Point(220, 63);
            this.Books.Name = "Books";
            this.Books.Size = new System.Drawing.Size(143, 74);
            this.Books.TabIndex = 1;
            this.Books.Text = "Books";
            this.Books.UseVisualStyleBackColor = false;
            this.Books.Click += new System.EventHandler(this.Books_Click);
            // 
            // Lending
            // 
            this.Lending.BackColor = System.Drawing.Color.LimeGreen;
            this.Lending.Font = new System.Drawing.Font("MV Boli", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lending.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.Lending.Location = new System.Drawing.Point(133, 174);
            this.Lending.Name = "Lending";
            this.Lending.Size = new System.Drawing.Size(143, 74);
            this.Lending.TabIndex = 2;
            this.Lending.Text = "Lending";
            this.Lending.UseVisualStyleBackColor = false;
            this.Lending.Click += new System.EventHandler(this.Lending_Click);
            // 
            // Exit
            // 
            this.Exit.BackColor = System.Drawing.Color.MediumSpringGreen;
            this.Exit.Font = new System.Drawing.Font("MV Boli", 15F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Exit.Location = new System.Drawing.Point(133, 298);
            this.Exit.Name = "Exit";
            this.Exit.Size = new System.Drawing.Size(143, 74);
            this.Exit.TabIndex = 4;
            this.Exit.Text = "Exit";
            this.Exit.UseVisualStyleBackColor = false;
            this.Exit.Click += new System.EventHandler(this.Exit_Click);
            // 
            // Library
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.ClientSize = new System.Drawing.Size(401, 384);
            this.Controls.Add(this.Exit);
            this.Controls.Add(this.Lending);
            this.Controls.Add(this.Books);
            this.Controls.Add(this.Members);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Library";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Library";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button Members;
        private System.Windows.Forms.Button Books;
        private System.Windows.Forms.Button Lending;
        private System.Windows.Forms.Button Exit;
    }
}

