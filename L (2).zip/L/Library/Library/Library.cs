﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Library
{
    public partial class Library : Form
    {
        public Library()
        {
            InitializeComponent();
        }

        private void Exit_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Are you want to exit app?", "Exit message", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                Application.Exit();
            }
        }

        private void Members_Click(object sender, EventArgs e)
        {
            Member member = new Member();
            member.Show();
        }

        private void Books_Click(object sender, EventArgs e)
        {
            Books books = new Books();
            books.Show();
        }

        private void Lending_Click(object sender, EventArgs e)
        {
            Lending lend = new Lending();
            lend.Show();
        }
    }
}