﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Library
{
    public class Book
    {
        public string BookName { get; set; }
        public string Author { get; set; }
        public string CodeBook { get; set; }
        public Book(string namebook, string author, string codebook)
        {
            BookName = namebook;
            Author = author;
            CodeBook = codebook;
        }
        public override string ToString()
        {
            return $"\t + {BookName} + \t + | + \t + {Author} + \t + | + \t + {CodeBook}";
        }
    }
}
